using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

namespace Exp10.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IMemoryCache _cache;

        public HomeController(ILogger<HomeController> logger, IMemoryCache cache)
        {
            _logger = logger;
            _cache = cache;
        }

        public IActionResult Index()
        {
            _logger.LogInformation("Home page loaded");

            if (!_cache.TryGetValue("msg", out string msg))
            {
                msg = "Cached Message";
                _cache.Set("msg", msg);
            }

            return Content(msg);
        }
    }
}